@extends('layouts.app')
@section('title', 'Welcome')
@section('content')
<div class="container">
    <div class="">
        <div class="">
            <h1 class="text-center">Welcome to APP</h1>
        </div>
        <div class="">
            <p>Get started by creating APP THING !</p>
        </div>
        <div class="">
            <a href="" class="">Go to APP</a>
        </div>
    </div>
</div>
@endsection