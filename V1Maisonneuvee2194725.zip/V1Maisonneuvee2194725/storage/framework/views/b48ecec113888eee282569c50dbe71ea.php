<?php $__env->startSection('title', 'Student'); ?>
<?php $__env->startSection('content'); ?>
<div class="container d-flex p-2 justify-content-center">
    <div class="card" style="width: 18rem;">
      <div class="card-body justify-center">
        <h5 class="card-title"><?php echo e($student->name); ?></h5>
        <h6 class="card-subtitle mb-2 text-muted"><?php echo e($student->email); ?></h6>
        <p class="card-text"><?php echo e($student->address); ?></p>
        <p class="card-text"><?php echo e($student->phone); ?></p>
        <p class="card-text"><?php echo e($student->date_of_birth); ?></p>
        <a href="#" class="card-link">Edit</a>
        <a href="#" class="card-link">Delete</a>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mateofortinlubin/Desktop/tp1/vigilant-octo-fiesta/Maisonneuvee2194725/resources/views/student/show.blade.php ENDPATH**/ ?>