<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
      Hello <strong>{{ $name }}</strong>,
    <p>{!!$body!!}</p>
  </body>
</html>