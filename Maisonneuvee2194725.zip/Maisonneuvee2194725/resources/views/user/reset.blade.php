@extends('layouts.app')
@section('title', 'Reset Password')
@section('content')
    @if(!$errors->isEmpty())
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <ul>
            @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>     
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>                
    @endif
    <div class="row justify-content-center mt-5 mb-5">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">@lang('lang.reset')</h5>
                </div>
                <div class="card-body">
                    <form  method="POST">
                        @csrf
                        @method('put')
                        <div class="mb-3">
                            <label for="password" class="form-label">@lang('password')</label>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>
                        <div class="mb-3">
                            <label for="password_confirmation" class="form-label">@lang('lang.password_confirm')</label>
                            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation">
                        </div>
                        <button type="submit" class="btn btn-primary">@lang('lang.reset')</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection