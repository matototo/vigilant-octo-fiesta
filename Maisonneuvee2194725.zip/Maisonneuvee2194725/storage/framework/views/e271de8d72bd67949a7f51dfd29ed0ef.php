<?php $__env->startSection('title', 'Edit'); ?>
<?php $__env->startSection('content'); ?>
    <?php if(!$errors->isEmpty()): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>     
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>                
    <?php endif; ?>
    <h1 class="mt-5 mb-4"><?php echo app('translator')->get('lang.edit_form'); ?></h1>
    <div class="row justify-content-center mt-5 mb-5">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title"><?php echo app('translator')->get('lang.update'); ?></h5>
                </div>
                <div class="card-body">
                    <form  method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label"><?php echo app('translator')->get('lang.user_name'); ?></label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $user->name)); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="username" class="form-label"><?php echo app('translator')->get('lang.username'); ?></label>
                                <input type="text" class="form-control" id="email" name="email"  value="<?php echo e(old('email', $user->email)); ?>">
                            </div>
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('lang.save'); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mateofortinlubin/23619/23619/4emSession/582-41B-MA/maison/tp1/vigilant-octo-fiesta/Maisonneuvee2194725/resources/views/user/edit.blade.php ENDPATH**/ ?>