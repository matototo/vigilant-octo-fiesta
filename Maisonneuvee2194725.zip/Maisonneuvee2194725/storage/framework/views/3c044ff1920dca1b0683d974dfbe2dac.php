<?php $__env->startSection('title', 'Edit Student'); ?>
<?php $__env->startSection('content'); ?>
    <h1 class="mt-5 mb-4">Edit Student</h1>
    <div class="row justify-content-center mt-5 mb-5">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">Edit Student</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $student->name)); ?>">
                            <?php if($errors->has('name')): ?>
                                <div class="text-danger mt-2">
                                    <?php echo e($errors->first('name')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="address" class="form-label">Address</label>
                            <textarea class="form-control" id="address" name="address" rows="3"><?php echo e(old('address', $student->address)); ?></textarea>
                            <?php if($errors->has('address')): ?>
                                <div class="text-danger mt-2">
                                    <?php echo e($errors->first('address')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone</label>
                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e(old('phone', $student->phone)); ?>">
                            <?php if($errors->has('phone')): ?>
                                <div class="text-danger mt-2">
                                    <?php echo e($errors->first('phone')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="text" class="form-control" id="email" name="email" value="<?php echo e(old('email', $student->email)); ?>">
                            <?php if($errors->has('email')): ?>
                                <div class="text-danger mt-2">
                                    <?php echo e($errors->first('email')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="date_of_birth" class="form-label">Date Of Birth</label>
                            <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" value="<?php echo e(old('date_of_birth', $student->date_of_birth)); ?>">
                            <?php if($errors->has('date_of_birth')): ?>
                                <div class="text-danger mt-2">
                                    <?php echo e($errors->first('date_of_birth')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mateofortinlubin/Desktop/tp1/vigilant-octo-fiesta/Maisonneuvee2194725/resources/views/student/edit.blade.php ENDPATH**/ ?>