<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <!-- link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
  <?php
    $locale = session()->get('locale')
  ?>
<div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
  <div class="container-fluid p-0">
    <header class="d-flex justify-content-between py-3 px-0">
      <ul class="nav nav-pills">
        <li><a href="/" class="nav-link px-2 link-secondary"><?php echo app('translator')->get('lang.home'); ?></a></li>
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"
              aria-expanded="false">Menu</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="<?php echo e(route('student.create')); ?>"><?php echo app('translator')->get('lang.student_new'); ?></a></li>
            <li><a class="dropdown-item" aria-current="page" href="<?php echo e(route('student.index')); ?>"><?php echo app('translator')->get('lang.student_list'); ?></a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"
              aria-expanded="false"><?php echo app('translator')->get('lang.users'); ?></a>
          <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo e(route('user.create')); ?>"><?php echo app('translator')->get('lang.user_new'); ?></a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('user.index')); ?>"><?php echo app('translator')->get('lang.user_list'); ?></a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"
              aria-expanded="false">Forum</a>
          <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo e(route('article.create')); ?>"><?php echo app('translator')->get('lang.article_new'); ?></a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('article.index')); ?>">Forum</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('category.create')); ?>"><?php echo app('translator')->get('lang.category'); ?></a></li>
          </ul>
        </li>
      </ul>
      <ul class="nav nav-pills mb-2 mb-sm-0">
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"
                aria-expanded="false"><?php echo app('translator')->get('lang.language'); ?> <?php echo e($locale == '' ? '' : "($locale)"); ?></a>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?php echo e(route('lang', 'en')); ?>"><?php echo app('translator')->get('lang.language_en'); ?></a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('lang', 'fr')); ?>"><?php echo app('translator')->get('lang.language_fr'); ?></a></li>
            </ul>
        </li>
        <li class="nav-item">
            <?php if(auth()->guard()->guest()): ?>
            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo app('translator')->get('lang.login'); ?></a>
            <?php else: ?>
            <a class="nav-link" href="<?php echo e(route('logout')); ?>"><?php echo app('translator')->get('lang.logout'); ?></a>
            <?php endif; ?>
        </li>
      </ul>
    </header>
  </div>

    <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show mt-2" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>

    



  <footer class="mt-auto">
    
      <span class="mb-3 mb-md-0 text-body-secondary">&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?> // <?php echo app('translator')->get('lang.rights'); ?></span>
    </div>
  </footer>
    </div>
</body>
    <!-- script -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>

</html><?php /**PATH /Users/mateofortinlubin/23619/23619/4emSession/582-41B-MA/maison/tp1/vigilant-octo-fiesta/Maisonneuvee2194725/resources/views/layouts/app.blade.php ENDPATH**/ ?>