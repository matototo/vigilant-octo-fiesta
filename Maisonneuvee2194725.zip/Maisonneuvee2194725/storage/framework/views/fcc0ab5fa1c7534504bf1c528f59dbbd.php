<?php $__env->startSection('title', 'Student List'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="mt-3 mb-2 text-center"><?php echo app('translator')->get('lang.student_list'); ?></h1>
<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-sm-3">
        <div class="card mb-4" style="width: 18rem;">
            <div class="card-body">
                <h4 class="card-title"><?php echo e($student->name); ?></h4>
                <p><?php echo e($student->address); ?></p>
                <p><?php echo e(preg_replace('~.*(\d{3})[^\d]{0,7}(\d{3})[^\d]{0,7}(\d{4}).*~', '($1) $2-$3', $student->phone)); ?></p>
                <p><?php echo e($student->email); ?></p>
                <p><?php echo e($student->date_of_birth); ?></p>
                <p><?php echo e($student->city->name); ?></p>
            </div>
            <div class="card-footer">
                <a href="<?php echo e(route('student.show', $student->id)); ?>" class="icon-link" ><?php echo app('translator')->get('lang.view'); ?></a>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-danger"><?php echo app('translator')->get('lang.no_students'); ?></div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mateofortinlubin/23619/23619/4emSession/582-41B-MA/maison/tp1/vigilant-octo-fiesta/Maisonneuvee2194725/resources/views/student/index.blade.php ENDPATH**/ ?>