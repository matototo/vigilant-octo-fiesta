<?php $__env->startSection('title', 'Article create'); ?>
<?php $__env->startSection('content'); ?>
    <?php if(!$errors->isEmpty()): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>     
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>                
    <?php endif; ?>
    <h1 class="mt-3 mb-2 text-center"><?php echo app('translator')->get('lang.article_new'); ?></h1>
    <div class="row justify-content-center mt-5 mb-5">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title"><?php echo app('translator')->get('lang.article_create'); ?></h5>
                </div>
                <div class="card-body">
                    <form  method="POST">
                        <?php echo csrf_field(); ?>
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="french-tab" data-bs-toggle="tab" data-bs-target="#french-tab-pane" type="button" role="tab" aria-controls="french-tab-pane" aria-selected="true"><?php echo app('translator')->get('lang.french'); ?></button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="englsih-tab" data-bs-toggle="tab" data-bs-target="#english-tab-pane" type="button" role="tab" aria-controls="english-tab-pane" aria-selected="false"><?php echo app('translator')->get('lang.english'); ?></button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="disabled-tab" data-bs-toggle="tab" data-bs-target="#disabled-tab-pane" type="button" role="tab" aria-controls="disabled-tab-pane" aria-selected="false" disabled><?php echo app('translator')->get('lang.spanish'); ?></button>
                            </li>
                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="french-tab-pane" role="tabpanel"   aria-labelledby="french-tab" tabindex="0">
                                    <div class="mb-3">
                                    <label for="title_fr" class="form-label"><?php echo app('translator')->get('lang.title_fr'); ?></label>
                                        <input type="text" class="form-control" id="title_fr" name="title_fr" value="<?php echo e(old('title_fr')); ?>">
                                        <?php if($errors->has('title_fr')): ?>
                                            <div class="text-danger mt-2">
                                                <?php echo e($errors->first('title_fr')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="description_fr" class="form-label"><?php echo app('translator')->get('lang.description_fr'); ?></label>
                                            <textarea name="description_fr" class="form-control" id="description_fr" value="<?php echo e(old('description_fr')); ?>"></textarea>
                                            <?php if($errors->has('description_fr')): ?>
                                            <div class="text-danger mt-2">
                                                <?php echo e($errors->first('description_fr')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="english-tab-pane" role="tabpanel" aria-labelledby="english-tab"  tabindex="0">
                                <div class="mb-3">
                                    <label for="title_en" class="form-label"><?php echo app('translator')->get('lang.title_en'); ?></label>
                                        <input type="text" class="form-control" id="title_en" name="title_en" value="<?php echo e(old('title_en')); ?>">
                                        <?php if($errors->has('title_en')): ?>
                                            <div class="text-danger mt-2">
                                                <?php echo e($errors->first('title_en')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="mb-3">
                                        <label for="description_en" class="form-label"><?php echo app('translator')->get('lang.description_en'); ?></label>
                                            <textarea name="description_en" class="form-control" id="description_en" value="<?php echo e(old('description_en')); ?>"></textarea>
                                            <?php if($errors->has('description_en')): ?>
                                            <div class="text-danger mt-2">
                                                <?php echo e($errors->first('description_en')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="contact-tab-pane" role="tabpanel" aria-labelledby="contact-tab"  tabindex="0">...</div>
                                <div class="tab-pane fade" id="disabled-tab-pane" role="tabpanel" aria-labelledby="disabled-tab" tabindex="0">...</div>
                            </div>
                        
                       
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('lang.save'); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mateofortinlubin/23619/23619/4emSession/582-41B-MA/maison/tp1/vigilant-octo-fiesta/Maisonneuvee2194725/resources/views/article/create.blade.php ENDPATH**/ ?>