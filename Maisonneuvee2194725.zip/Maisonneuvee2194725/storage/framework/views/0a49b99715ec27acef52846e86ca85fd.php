<?php $__env->startSection('title', 'Welcome'); ?>
<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="">
            <h1 class="text-center">Welcome to APP</h1>
        </div>
        <div class="">
            <p>Get started by creating APP THING !</p>
        </div>
        <div class="">
            <a href="" class="">Go to APP</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mateofortinlubin/Desktop/tp1/vigilant-octo-fiesta/Maisonneuvee2194725/resources/views/welcome.blade.php ENDPATH**/ ?>