<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
      Hello <strong><?php echo e($name); ?></strong>,
    <p><?php echo $body; ?></p>
  </body>
</html><?php /**PATH /Users/mateofortinlubin/23619/23619/4emSession/582-41B-MA/maison/tp1/vigilant-octo-fiesta/Maisonneuvee2194725/resources/views/user/mail.blade.php ENDPATH**/ ?>