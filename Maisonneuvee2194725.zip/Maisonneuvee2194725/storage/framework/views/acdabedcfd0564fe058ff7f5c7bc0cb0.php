<?php $__env->startSection('title', 'Article edit'); ?>
<?php $__env->startSection('content'); ?>
    <?php if(!$errors->isEmpty()): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>     
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>                
    <?php endif; ?>
    <h1 class="mt-3 mb-2 text-center"><?php echo app('translator')->get('lang.article_edit'); ?></h1>
    <div class="row justify-content-center mt-5 mb-5">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title"><?php echo app('translator')->get('lang.edit_form'); ?></h5>
                </div>
                <div class="card-body">
                    <form  method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="title" class="form-label"><?php echo app('translator')->get('lang.title'); ?></label>
                            <input type="text" class="form-control" id="title" name="title" value="<?php echo e(old('title', $article->title)); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label"><?php echo app('translator')->get('lang.description'); ?></label>
                                <textarea name="description" class="form-control" id="description"><?php echo e(old('description', $article->description)); ?></textarea>

                        </div>
                        <div class="mb-3">
                            <label for="category_id" class="form-label"><?php echo app('translator')->get('lang.category'); ?></label>
                                <select name="category_id" id="category_id" class="form-control">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category['id']); ?>" <?php if($category['id'] == old('category_id')): ?> selected <?php endif; ?>><?php echo e($category['category']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </select>
                                <?php if($errors->has('category_id')): ?>
                                <div class="text-danger mt-2">
                                    <?php echo e($errors->first('category_id')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('lang.save'); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mateofortinlubin/23619/23619/4emSession/582-41B-MA/maison/tp1/vigilant-octo-fiesta/Maisonneuvee2194725/resources/views/article/edit.blade.php ENDPATH**/ ?>