<?php $__env->startSection('title', 'Student'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="mt-3 mb-2 text-center"><?php echo app('translator')->get('lang.student_card'); ?></h1>
<div class="d-flex p-2 justify-content-center">
    <div class="card" style="width: 18rem;">
      <div class="card-body justify-center">
        <h5 class="card-title"><?php echo e($student->name); ?></h5>
        <h6 class="card-subtitle mb-2 text-muted"><?php echo e($student->email); ?></h6>
        <p class="card-text"><?php echo e($student->address); ?></p>
        <p class="card-text"><?php echo e($student->phone); ?></p>
        <p class="card-text"><?php echo e($student->date_of_birth); ?></p>
        <p><?php echo e($student->city->name); ?></p>
        <div class="d-flex justify-content-between">
          <a href="<?php echo e(route('student.edit', $student->id)); ?>" class="card-link"><?php echo app('translator')->get('lang.edit'); ?></a>
          <!-- <a href="#" class="card-link">Delete</a> -->
          <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#exampleModal"><?php echo app('translator')->get('lang.delete'); ?>
          </button>
        </div>
      </div>
    </div>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Are you sure about that ?</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <form action="<?php echo e(route('student.destroy', $student->id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('delete'); ?>
          <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mateofortinlubin/23619/23619/4emSession/582-41B-MA/maison/tp1/vigilant-octo-fiesta/Maisonneuvee2194725/resources/views/student/show.blade.php ENDPATH**/ ?>