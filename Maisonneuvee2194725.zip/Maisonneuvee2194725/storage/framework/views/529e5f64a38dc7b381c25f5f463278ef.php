<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('content'); ?>
    <h1 class="mt-3 mb-2 text-center">Users</h1>
    <div class="row justify-content-center mt-5 mb-5">
        <div class="col-md-12">
            <div class="card mt-3">
                <div class="card-header">
                    <h5 class="card-title"><?php echo app('translator')->get('lang.users'); ?></h5>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col"><?php echo app('translator')->get('lang.user'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('lang.view'); ?></th>
                        <th scope="col"><?php echo app('translator')->get('lang.edit'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($user->id); ?></th>
                            <td><?php echo e($user->name); ?></td>
                            <td>
                                <a href="<?php echo e(route('user.show', $user->id)); ?>" class="icon-link" ><?php echo app('translator')->get('lang.view'); ?></a>
                            </td>
                            <td>
                                <a href="<?php echo e(route('user.edit', $user->id)); ?>" class="icon-link" ><?php echo app('translator')->get('lang.edit'); ?></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($users); ?>

                </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mateofortinlubin/23619/23619/4emSession/582-41B-MA/maison/tp1/vigilant-octo-fiesta/Maisonneuvee2194725/resources/views/user/index.blade.php ENDPATH**/ ?>