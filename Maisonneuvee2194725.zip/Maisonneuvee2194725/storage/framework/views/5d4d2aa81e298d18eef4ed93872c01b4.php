<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        body{
            font-family: Arial, Helvetica, sans-serif
        }
    </style>
</head>
<body>
    <h1><?php echo e($article->title); ?></h1>
    <p><?php echo e($article->description); ?></p>
    <hr>
    <ul>
        <li><strong>Author :</strong> <?php echo e($article->user->name); ?></li>
        <li><strong>Category :</strong> <?php echo e($article->category ? $article->category->category[app()->getLocale()] ?? $article->category->category['en'] : ''); ?></li>
    </ul>
    
    <hr>   
</body>
</html><?php /**PATH /Users/mateofortinlubin/23619/23619/4emSession/582-41B-MA/maison/tp1/vigilant-octo-fiesta/Maisonneuvee2194725/resources/views/article/show-pdf.blade.php ENDPATH**/ ?>