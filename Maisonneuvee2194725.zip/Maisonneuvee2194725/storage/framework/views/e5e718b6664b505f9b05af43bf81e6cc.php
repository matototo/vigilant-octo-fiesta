<?php $__env->startSection('title', 'Article List'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="mt-3 mb-2 text-center"><?php echo app('translator')->get('lang.article_forum'); ?></h1>
<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="card mb-4" style="width: 18rem;">
        <div class="card-body p-2 p-sm-3">
            <h4 class="card-title"><?php echo e($article->title); ?></h4>
            <p><?php echo e($article->description); ?></p>
            <p><?php echo e($article->user->name); ?></p>
            <p><?php echo e($article->category ? $article->category->title[app()->getLocale()] ?? $article->category->title['en'] : ''); ?>

        </div>
        <div class="card-footer d-flex justify-content-between">
        <?php if(auth()->guard()->check()): ?>
          <a href="<?php echo e(route('article.show', $article->id)); ?>" class="icon-link"><?php echo app('translator')->get('lang.view'); ?></a>
          <?php if(Auth::user()->id == $article->user->id ): ?>
              <a href="<?php echo e(route('article.edit', $article->id)); ?>" class="icon-link"><?php echo app('translator')->get('lang.edit'); ?></a>
              <a href="<?php echo e(route('article.destroy', $article->id)); ?>" class="icon-link"><?php echo app('translator')->get('lang.delete'); ?></a>
          <?php endif; ?>
          <?php endif; ?>
        </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-danger"><?php echo app('translator')->get('lang.no_articles'); ?></div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mateofortinlubin/23619/23619/4emSession/582-41B-MA/maison/tp1/vigilant-octo-fiesta/Maisonneuvee2194725/resources/views/article/index.blade.php ENDPATH**/ ?>