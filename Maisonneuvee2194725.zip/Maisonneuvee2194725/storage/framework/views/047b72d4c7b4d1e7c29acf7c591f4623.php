<?php $__env->startSection('title', 'Add Student'); ?>
<?php $__env->startSection('content'); ?>
    <h1 class="mt-3 mb-2 text-center"><?php echo app('translator')->get('lang.student_submit'); ?></h1>
    <div class="row justify-content-center mt-5 mb-5">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title"><?php echo app('translator')->get('lang.student_add'); ?></h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('student.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label"><?php echo app('translator')->get('lang.student_name'); ?></label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>">
                            <?php if($errors->has('name')): ?>
                                <div class="text-danger mt-2">
                                    <?php echo e($errors->first('name')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="address" class="form-label"><?php echo app('translator')->get('lang.student_address'); ?></label>
                            <textarea class="form-control" id="address" name="address" rows="3"><?php echo e(old('address')); ?></textarea>
                            <?php if($errors->has('address')): ?>
                                <div class="text-danger mt-2">
                                    <?php echo e($errors->first('address')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label"><?php echo app('translator')->get('lang.student_phone'); ?></label>
                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e(old('phone')); ?>">
                            <?php if($errors->has('phone')): ?>
                                <div class="text-danger mt-2">
                                    <?php echo e($errors->first('phone')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label"><?php echo app('translator')->get('lang.student_email'); ?></label>
                            <input type="text" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>">
                            <?php if($errors->has('email')): ?>
                                <div class="text-danger mt-2">
                                    <?php echo e($errors->first('email')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="date_of_birth" class="form-label"><?php echo app('translator')->get('lang.student_date'); ?></label>
                            <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>">
                            <?php if($errors->has('date_of_birth')): ?>
                                <div class="text-danger mt-2">
                                    <?php echo e($errors->first('date_of_birth')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <label for="city_id"><?php echo app('translator')->get('lang.student_city'); ?></label>
                        <select name="city_id" class="form-select mb-2" aria-label="City select" >
                        <option selected><?php echo app('translator')->get('lang.student_open'); ?></option>
                        
                        
                        <?php $__empty_1 = true; $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($city->id); ?>" <?php if($city['id'] == old('city_id')): ?> selected <?php endif; ?>><?php echo e($city->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="alert alert-danger"><?php echo app('translator')->get('login.student_no_city'); ?></p>
                         <?php endif; ?>
                        </select>
                        <?php if($errors->has('city')): ?>
                            <div class="text-danger mt-2">
                                <?php echo e($errors->first('city')); ?>

                            </div>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('lang.save'); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mateofortinlubin/23619/23619/4emSession/582-41B-MA/maison/tp1/vigilant-octo-fiesta/Maisonneuvee2194725/resources/views/student/create.blade.php ENDPATH**/ ?>