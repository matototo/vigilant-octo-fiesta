<?php $__env->startSection('title', 'Welcome'); ?>
<?php $__env->startSection('content'); ?>

<main class="px-3 mh-100">
    <h1 class="mt-3 mb-2 text-center"><?php echo app('translator')->get('lang.welcome'); ?></h1>
    <p class="lead"><?php echo app('translator')->get('lang.welcome_text'); ?></p>
    <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body-tertiary">
    <div class="col-md-6 p-lg-5 mx-auto my-5">
      <h1 class="display-3 fw-bold"><?php echo app('translator')->get('lang.welcome_slogan'); ?></h1>
      <h3 class="fw-normal text-muted mb-3"><?php echo app('translator')->get('lang.welcome_aperture'); ?></h3>
      <div class="d-flex gap-3 justify-content-center lead fw-normal">
        <a class="icon-link" href="#">
        <?php echo app('translator')->get('lang.welcome_learn'); ?>
          <svg class="bi"><use xlink:href="#chevron-right"/></svg>
        </a>
        <a class="icon-link" href="#">
        <?php echo app('translator')->get('lang.welcome_buy'); ?>
          <svg class="bi"><use xlink:href="#chevron-right"/></svg>
        </a>
      </div>
    </div>
  </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mateofortinlubin/23619/23619/4emSession/582-41B-MA/maison/tp1/vigilant-octo-fiesta/Maisonneuvee2194725/resources/views/welcome.blade.php ENDPATH**/ ?>